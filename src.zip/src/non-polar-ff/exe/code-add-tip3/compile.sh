#!/bin/bash

g++ -O3 -o add-tip3 add_tip3.cpp

cp add-tip3 ../../../../bin
chmod g+rx ../../../../bin/add-tip3
