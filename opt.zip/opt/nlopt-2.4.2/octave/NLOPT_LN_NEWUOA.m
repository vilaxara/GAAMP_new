% NLOPT_LN_NEWUOA: NEWUOA unconstrained optimization via quadratic models (local, no-derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_LN_NEWUOA
  val = 26;
